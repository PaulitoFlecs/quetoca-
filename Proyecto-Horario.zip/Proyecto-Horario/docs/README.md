# Proyecto Horario

Documentación inicial del sistema de horarios y carga horaria.

